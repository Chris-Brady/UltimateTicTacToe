package ultimatetictactoe;

public class main
{
    public static void main(String[] args)
    {
        UltimateTicTacToeClient utttc = new UltimateTicTacToeClient();
    }
}
